#!/bin/bash

base_dir=`pwd`

LOG_DIR=$base_dir/logs
KAFKA_LOG4J_OPTS="-Dlog4j.configuration=file:$base_dir/config/log4j.properties"

#if [ ! -e "$LOG_DIR" ]; then
#    echo "mkdir $LOG_DIR"
#    mkdir  $LOG_DIR
#fi

export LOG_DIR KAFKA_LOG4J_OPTS

echo "strapup kafka_server_start.sh"
kafka-server-start.sh config/server.properties
