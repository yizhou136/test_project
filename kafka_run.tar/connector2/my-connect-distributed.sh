#!/bin/sh

base_dir=`pwd`

LOG_DIR=$base_dir/logs
KAFKA_LOG4J_OPTS="-Dlog4j.configuration=file:$base_dir/config/connect-log4j.properties"
export LOG_DIR KAFKA_LOG4J_OPTS

echo "strapup connect-standalone.sh '$@'"
exec connect-distributed.sh "$@"
